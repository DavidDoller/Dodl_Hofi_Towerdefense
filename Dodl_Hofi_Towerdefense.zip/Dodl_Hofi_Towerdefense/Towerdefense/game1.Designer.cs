﻿
namespace Towerdefense
{
    partial class game1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.playtimer = new System.Windows.Forms.Timer(this.components);
            this.enemyspawning = new System.Windows.Forms.Timer(this.components);
            this.lbl_test = new System.Windows.Forms.Label();
            this.bullet_speed = new System.Windows.Forms.Timer(this.components);
            this.lbl_smallestenemy = new System.Windows.Forms.Label();
            this.btn_PlaceTower2 = new System.Windows.Forms.Button();
            this.btn_PlaceTower3 = new System.Windows.Forms.Button();
            this.btn_PlaceTower4 = new System.Windows.Forms.Button();
            this.btn_PlaceTower6 = new System.Windows.Forms.Button();
            this.btn_PlaceTower7 = new System.Windows.Forms.Button();
            this.btn_PlaceTower8 = new System.Windows.Forms.Button();
            this.btn_PlaceTower10 = new System.Windows.Forms.Button();
            this.btn_PlaceTower9 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_mageTowerPrice = new System.Windows.Forms.Label();
            this.lbl_archerTowerPrice = new System.Windows.Forms.Label();
            this.lbl_bombTowerPrice = new System.Windows.Forms.Label();
            this.lbl_ninjaTowerPrice = new System.Windows.Forms.Label();
            this.lbl_maschineGunPrice = new System.Windows.Forms.Label();
            this.btn_PlaceTower5 = new System.Windows.Forms.Button();
            this.lbl_health = new System.Windows.Forms.Label();
            this.lbl_coins = new System.Windows.Forms.Label();
            this.pnl_pause = new System.Windows.Forms.Panel();
            this.pnl_start = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_wave = new System.Windows.Forms.Label();
            this.lbl_redlooncounter = new System.Windows.Forms.Label();
            this.lbl_bluelooncounter = new System.Windows.Forms.Label();
            this.lbl_waveCooldown = new System.Windows.Forms.Label();
            this.bullet_spawning = new System.Windows.Forms.Timer(this.components);
            this.pb_mageNoCoins = new System.Windows.Forms.PictureBox();
            this.pb_backgroundCoins = new System.Windows.Forms.PictureBox();
            this.pb_spawn = new System.Windows.Forms.PictureBox();
            this.pb_ninjaTower = new System.Windows.Forms.PictureBox();
            this.pb_maschingunTower = new System.Windows.Forms.PictureBox();
            this.pb_BombTower = new System.Windows.Forms.PictureBox();
            this.pb_archerTower = new System.Windows.Forms.PictureBox();
            this.pb_mageTower = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pb_core = new System.Windows.Forms.PictureBox();
            this.pb_corner5 = new System.Windows.Forms.PictureBox();
            this.pb_corner4 = new System.Windows.Forms.PictureBox();
            this.pb_corner3 = new System.Windows.Forms.PictureBox();
            this.pb_corner2 = new System.Windows.Forms.PictureBox();
            this.pb_corner1 = new System.Windows.Forms.PictureBox();
            this.pb_tower9 = new System.Windows.Forms.PictureBox();
            this.pb_tower10 = new System.Windows.Forms.PictureBox();
            this.pb_tower8 = new System.Windows.Forms.PictureBox();
            this.pb_tower7 = new System.Windows.Forms.PictureBox();
            this.pb_tower2 = new System.Windows.Forms.PictureBox();
            this.pb_tower3 = new System.Windows.Forms.PictureBox();
            this.pb_tower6 = new System.Windows.Forms.PictureBox();
            this.pb_tower5 = new System.Windows.Forms.PictureBox();
            this.pb_tower4 = new System.Windows.Forms.PictureBox();
            this.pb_archNoCoins = new System.Windows.Forms.PictureBox();
            this.pb_bombNoCoins = new System.Windows.Forms.PictureBox();
            this.pb_ninjaNoCoins = new System.Windows.Forms.PictureBox();
            this.pb_gunNoCoins = new System.Windows.Forms.PictureBox();
            this.pb_rangeTower1 = new System.Windows.Forms.PictureBox();
            this.btn_PlaceTower1 = new System.Windows.Forms.Button();
            this.pb_tower1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mageNoCoins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_backgroundCoins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_spawn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ninjaTower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_maschingunTower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_BombTower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_archerTower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mageTower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_core)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_archNoCoins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bombNoCoins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ninjaNoCoins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_gunNoCoins)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rangeTower1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower1)).BeginInit();
            this.SuspendLayout();
            // 
            // playtimer
            // 
            this.playtimer.Enabled = true;
            this.playtimer.Tick += new System.EventHandler(this.playtimer_Tick);
            // 
            // enemyspawning
            // 
            this.enemyspawning.Enabled = true;
            this.enemyspawning.Interval = 1000;
            this.enemyspawning.Tick += new System.EventHandler(this.enemyspawning_Tick);
            // 
            // lbl_test
            // 
            this.lbl_test.AutoSize = true;
            this.lbl_test.Location = new System.Drawing.Point(106, 145);
            this.lbl_test.Name = "lbl_test";
            this.lbl_test.Size = new System.Drawing.Size(0, 13);
            this.lbl_test.TabIndex = 39;
            // 
            // bullet_speed
            // 
            this.bullet_speed.Enabled = true;
            this.bullet_speed.Interval = 50;
            this.bullet_speed.Tick += new System.EventHandler(this.bullet_speed_Tick);
            // 
            // lbl_smallestenemy
            // 
            this.lbl_smallestenemy.AutoSize = true;
            this.lbl_smallestenemy.Location = new System.Drawing.Point(88, 123);
            this.lbl_smallestenemy.Name = "lbl_smallestenemy";
            this.lbl_smallestenemy.Size = new System.Drawing.Size(35, 13);
            this.lbl_smallestenemy.TabIndex = 40;
            this.lbl_smallestenemy.Text = "label1";
            // 
            // btn_PlaceTower2
            // 
            this.btn_PlaceTower2.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower2.Location = new System.Drawing.Point(158, 420);
            this.btn_PlaceTower2.Name = "btn_PlaceTower2";
            this.btn_PlaceTower2.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower2.TabIndex = 48;
            this.btn_PlaceTower2.Text = "Place Here";
            this.btn_PlaceTower2.UseVisualStyleBackColor = false;
            this.btn_PlaceTower2.Click += new System.EventHandler(this.btn_PlaceTower2_Click);
            // 
            // btn_PlaceTower3
            // 
            this.btn_PlaceTower3.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower3.Location = new System.Drawing.Point(348, 421);
            this.btn_PlaceTower3.Name = "btn_PlaceTower3";
            this.btn_PlaceTower3.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower3.TabIndex = 49;
            this.btn_PlaceTower3.Text = "Place Here";
            this.btn_PlaceTower3.UseVisualStyleBackColor = false;
            this.btn_PlaceTower3.Click += new System.EventHandler(this.btn_PlaceTower3_Click);
            // 
            // btn_PlaceTower4
            // 
            this.btn_PlaceTower4.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower4.Location = new System.Drawing.Point(279, 185);
            this.btn_PlaceTower4.Name = "btn_PlaceTower4";
            this.btn_PlaceTower4.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower4.TabIndex = 50;
            this.btn_PlaceTower4.Text = "Place Here";
            this.btn_PlaceTower4.UseVisualStyleBackColor = false;
            this.btn_PlaceTower4.Click += new System.EventHandler(this.btn_PlaceTower4_Click);
            // 
            // btn_PlaceTower6
            // 
            this.btn_PlaceTower6.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower6.Location = new System.Drawing.Point(453, 185);
            this.btn_PlaceTower6.Name = "btn_PlaceTower6";
            this.btn_PlaceTower6.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower6.TabIndex = 52;
            this.btn_PlaceTower6.Text = "Place Here";
            this.btn_PlaceTower6.UseVisualStyleBackColor = false;
            this.btn_PlaceTower6.Click += new System.EventHandler(this.btn_PlaceTower6_Click);
            // 
            // btn_PlaceTower7
            // 
            this.btn_PlaceTower7.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower7.Location = new System.Drawing.Point(604, 185);
            this.btn_PlaceTower7.Name = "btn_PlaceTower7";
            this.btn_PlaceTower7.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower7.TabIndex = 53;
            this.btn_PlaceTower7.Text = "Place Here";
            this.btn_PlaceTower7.UseVisualStyleBackColor = false;
            this.btn_PlaceTower7.Click += new System.EventHandler(this.btn_PlaceTower7_Click);
            // 
            // btn_PlaceTower8
            // 
            this.btn_PlaceTower8.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower8.Location = new System.Drawing.Point(604, 350);
            this.btn_PlaceTower8.Name = "btn_PlaceTower8";
            this.btn_PlaceTower8.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower8.TabIndex = 54;
            this.btn_PlaceTower8.Text = "Place Here";
            this.btn_PlaceTower8.UseVisualStyleBackColor = false;
            this.btn_PlaceTower8.Click += new System.EventHandler(this.btn_PlaceTower8_Click);
            // 
            // btn_PlaceTower10
            // 
            this.btn_PlaceTower10.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower10.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower10.Location = new System.Drawing.Point(810, 196);
            this.btn_PlaceTower10.Name = "btn_PlaceTower10";
            this.btn_PlaceTower10.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower10.TabIndex = 55;
            this.btn_PlaceTower10.Text = "Place Here";
            this.btn_PlaceTower10.UseVisualStyleBackColor = false;
            this.btn_PlaceTower10.Click += new System.EventHandler(this.btn_PlaceTower10_Click);
            // 
            // btn_PlaceTower9
            // 
            this.btn_PlaceTower9.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower9.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower9.Location = new System.Drawing.Point(810, 118);
            this.btn_PlaceTower9.Name = "btn_PlaceTower9";
            this.btn_PlaceTower9.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower9.TabIndex = 56;
            this.btn_PlaceTower9.Text = "Place Here";
            this.btn_PlaceTower9.UseVisualStyleBackColor = false;
            this.btn_PlaceTower9.Click += new System.EventHandler(this.btn_PlaceTower9_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 57;
            this.label1.Text = "label1";
            // 
            // lbl_mageTowerPrice
            // 
            this.lbl_mageTowerPrice.AutoSize = true;
            this.lbl_mageTowerPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lbl_mageTowerPrice.Location = new System.Drawing.Point(40, 622);
            this.lbl_mageTowerPrice.Name = "lbl_mageTowerPrice";
            this.lbl_mageTowerPrice.Size = new System.Drawing.Size(25, 13);
            this.lbl_mageTowerPrice.TabIndex = 58;
            this.lbl_mageTowerPrice.Text = "200";
            // 
            // lbl_archerTowerPrice
            // 
            this.lbl_archerTowerPrice.AutoSize = true;
            this.lbl_archerTowerPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lbl_archerTowerPrice.Location = new System.Drawing.Point(261, 622);
            this.lbl_archerTowerPrice.Name = "lbl_archerTowerPrice";
            this.lbl_archerTowerPrice.Size = new System.Drawing.Size(25, 13);
            this.lbl_archerTowerPrice.TabIndex = 59;
            this.lbl_archerTowerPrice.Text = "250";
            // 
            // lbl_bombTowerPrice
            // 
            this.lbl_bombTowerPrice.AutoSize = true;
            this.lbl_bombTowerPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lbl_bombTowerPrice.Location = new System.Drawing.Point(479, 622);
            this.lbl_bombTowerPrice.Name = "lbl_bombTowerPrice";
            this.lbl_bombTowerPrice.Size = new System.Drawing.Size(25, 13);
            this.lbl_bombTowerPrice.TabIndex = 60;
            this.lbl_bombTowerPrice.Text = "300";
            // 
            // lbl_ninjaTowerPrice
            // 
            this.lbl_ninjaTowerPrice.AutoSize = true;
            this.lbl_ninjaTowerPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lbl_ninjaTowerPrice.Location = new System.Drawing.Point(684, 624);
            this.lbl_ninjaTowerPrice.Name = "lbl_ninjaTowerPrice";
            this.lbl_ninjaTowerPrice.Size = new System.Drawing.Size(25, 13);
            this.lbl_ninjaTowerPrice.TabIndex = 61;
            this.lbl_ninjaTowerPrice.Text = "350";
            // 
            // lbl_maschineGunPrice
            // 
            this.lbl_maschineGunPrice.AutoSize = true;
            this.lbl_maschineGunPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.lbl_maschineGunPrice.Location = new System.Drawing.Point(888, 622);
            this.lbl_maschineGunPrice.Name = "lbl_maschineGunPrice";
            this.lbl_maschineGunPrice.Size = new System.Drawing.Size(25, 13);
            this.lbl_maschineGunPrice.TabIndex = 62;
            this.lbl_maschineGunPrice.Text = "400";
            // 
            // btn_PlaceTower5
            // 
            this.btn_PlaceTower5.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower5.Location = new System.Drawing.Point(289, 54);
            this.btn_PlaceTower5.Name = "btn_PlaceTower5";
            this.btn_PlaceTower5.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower5.TabIndex = 68;
            this.btn_PlaceTower5.Text = "Place Here";
            this.btn_PlaceTower5.UseVisualStyleBackColor = false;
            this.btn_PlaceTower5.Click += new System.EventHandler(this.btn_PlaceTower5_Click_1);
            // 
            // lbl_health
            // 
            this.lbl_health.AutoSize = true;
            this.lbl_health.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lbl_health.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold);
            this.lbl_health.Location = new System.Drawing.Point(3, 9);
            this.lbl_health.Name = "lbl_health";
            this.lbl_health.Size = new System.Drawing.Size(116, 31);
            this.lbl_health.TabIndex = 72;
            this.lbl_health.Text = "Health: ";
            // 
            // lbl_coins
            // 
            this.lbl_coins.AutoSize = true;
            this.lbl_coins.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lbl_coins.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_coins.ForeColor = System.Drawing.Color.Black;
            this.lbl_coins.Location = new System.Drawing.Point(807, 9);
            this.lbl_coins.Name = "lbl_coins";
            this.lbl_coins.Size = new System.Drawing.Size(106, 31);
            this.lbl_coins.TabIndex = 71;
            this.lbl_coins.Text = "Coins: ";
            // 
            // pnl_pause
            // 
            this.pnl_pause.Location = new System.Drawing.Point(883, 479);
            this.pnl_pause.Name = "pnl_pause";
            this.pnl_pause.Size = new System.Drawing.Size(50, 50);
            this.pnl_pause.TabIndex = 64;
            this.pnl_pause.Click += new System.EventHandler(this.pnl_pause_Click);
            this.pnl_pause.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_pause_Paint);
            // 
            // pnl_start
            // 
            this.pnl_start.Location = new System.Drawing.Point(938, 479);
            this.pnl_start.Name = "pnl_start";
            this.pnl_start.Size = new System.Drawing.Size(50, 50);
            this.pnl_start.TabIndex = 63;
            this.pnl_start.Click += new System.EventHandler(this.pnl_start_Click);
            this.pnl_start.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_start_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 73;
            this.label2.Text = "E - Exit Game";
            // 
            // lbl_wave
            // 
            this.lbl_wave.AutoSize = true;
            this.lbl_wave.Location = new System.Drawing.Point(609, 516);
            this.lbl_wave.Name = "lbl_wave";
            this.lbl_wave.Size = new System.Drawing.Size(42, 13);
            this.lbl_wave.TabIndex = 74;
            this.lbl_wave.Text = "Wave: ";
            // 
            // lbl_redlooncounter
            // 
            this.lbl_redlooncounter.AutoSize = true;
            this.lbl_redlooncounter.Location = new System.Drawing.Point(382, 469);
            this.lbl_redlooncounter.Name = "lbl_redlooncounter";
            this.lbl_redlooncounter.Size = new System.Drawing.Size(30, 13);
            this.lbl_redlooncounter.TabIndex = 75;
            this.lbl_redlooncounter.Text = "temp";
            // 
            // lbl_bluelooncounter
            // 
            this.lbl_bluelooncounter.AutoSize = true;
            this.lbl_bluelooncounter.Location = new System.Drawing.Point(382, 499);
            this.lbl_bluelooncounter.Name = "lbl_bluelooncounter";
            this.lbl_bluelooncounter.Size = new System.Drawing.Size(30, 13);
            this.lbl_bluelooncounter.TabIndex = 76;
            this.lbl_bluelooncounter.Text = "temp";
            // 
            // lbl_waveCooldown
            // 
            this.lbl_waveCooldown.AutoSize = true;
            this.lbl_waveCooldown.Location = new System.Drawing.Point(298, 516);
            this.lbl_waveCooldown.Name = "lbl_waveCooldown";
            this.lbl_waveCooldown.Size = new System.Drawing.Size(36, 13);
            this.lbl_waveCooldown.TabIndex = 77;
            this.lbl_waveCooldown.Text = "Timer:";
            // 
            // bullet_spawning
            // 
            this.bullet_spawning.Enabled = true;
            this.bullet_spawning.Interval = 3000;
            this.bullet_spawning.Tick += new System.EventHandler(this.bullet_spawning_Tick);
            // 
            // pb_mageNoCoins
            // 
            this.pb_mageNoCoins.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_mageNoCoins.BackgroundImage = global::Towerdefense.Properties.Resources.notEnoughCoins;
            this.pb_mageNoCoins.Location = new System.Drawing.Point(29, 568);
            this.pb_mageNoCoins.Name = "pb_mageNoCoins";
            this.pb_mageNoCoins.Size = new System.Drawing.Size(53, 53);
            this.pb_mageNoCoins.TabIndex = 78;
            this.pb_mageNoCoins.TabStop = false;
            this.pb_mageNoCoins.Tag = "mageNoCoins";
            // 
            // pb_backgroundCoins
            // 
            this.pb_backgroundCoins.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pb_backgroundCoins.Location = new System.Drawing.Point(0, -3);
            this.pb_backgroundCoins.Name = "pb_backgroundCoins";
            this.pb_backgroundCoins.Size = new System.Drawing.Size(1000, 51);
            this.pb_backgroundCoins.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_backgroundCoins.TabIndex = 70;
            this.pb_backgroundCoins.TabStop = false;
            // 
            // pb_spawn
            // 
            this.pb_spawn.BackColor = System.Drawing.Color.Lime;
            this.pb_spawn.Location = new System.Drawing.Point(91, 553);
            this.pb_spawn.Name = "pb_spawn";
            this.pb_spawn.Size = new System.Drawing.Size(54, 38);
            this.pb_spawn.TabIndex = 38;
            this.pb_spawn.TabStop = false;
            this.pb_spawn.Tag = "straight";
            // 
            // pb_ninjaTower
            // 
            this.pb_ninjaTower.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_ninjaTower.BackgroundImage = global::Towerdefense.Properties.Resources.NinjaTower;
            this.pb_ninjaTower.Location = new System.Drawing.Point(670, 568);
            this.pb_ninjaTower.Name = "pb_ninjaTower";
            this.pb_ninjaTower.Size = new System.Drawing.Size(57, 53);
            this.pb_ninjaTower.TabIndex = 46;
            this.pb_ninjaTower.TabStop = false;
            this.pb_ninjaTower.Tag = "ninjaTowerselecter";
            this.pb_ninjaTower.Click += new System.EventHandler(this.pb_ninjaTower_Click);
            // 
            // pb_maschingunTower
            // 
            this.pb_maschingunTower.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_maschingunTower.BackgroundImage = global::Towerdefense.Properties.Resources.machineGunTower;
            this.pb_maschingunTower.Location = new System.Drawing.Point(877, 568);
            this.pb_maschingunTower.Name = "pb_maschingunTower";
            this.pb_maschingunTower.Size = new System.Drawing.Size(59, 53);
            this.pb_maschingunTower.TabIndex = 45;
            this.pb_maschingunTower.TabStop = false;
            this.pb_maschingunTower.Tag = "maschingunTowerselecter";
            this.pb_maschingunTower.Click += new System.EventHandler(this.pb_maschingunTower_Click);
            // 
            // pb_BombTower
            // 
            this.pb_BombTower.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_BombTower.BackgroundImage = global::Towerdefense.Properties.Resources.BombTowerrework;
            this.pb_BombTower.Location = new System.Drawing.Point(465, 568);
            this.pb_BombTower.Name = "pb_BombTower";
            this.pb_BombTower.Size = new System.Drawing.Size(57, 53);
            this.pb_BombTower.TabIndex = 44;
            this.pb_BombTower.TabStop = false;
            this.pb_BombTower.Tag = "BombTowerselecter";
            this.pb_BombTower.Click += new System.EventHandler(this.pb_BombTower_Click);
            // 
            // pb_archerTower
            // 
            this.pb_archerTower.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_archerTower.BackgroundImage = global::Towerdefense.Properties.Resources.archerTowerrework;
            this.pb_archerTower.Location = new System.Drawing.Point(249, 568);
            this.pb_archerTower.Name = "pb_archerTower";
            this.pb_archerTower.Size = new System.Drawing.Size(57, 53);
            this.pb_archerTower.TabIndex = 43;
            this.pb_archerTower.TabStop = false;
            this.pb_archerTower.Tag = "archerTowerselecter";
            this.pb_archerTower.Click += new System.EventHandler(this.pb_archerTower_Click);
            // 
            // pb_mageTower
            // 
            this.pb_mageTower.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_mageTower.BackgroundImage = global::Towerdefense.Properties.Resources.mageTower;
            this.pb_mageTower.Location = new System.Drawing.Point(24, 568);
            this.pb_mageTower.Name = "pb_mageTower";
            this.pb_mageTower.Size = new System.Drawing.Size(56, 53);
            this.pb_mageTower.TabIndex = 42;
            this.pb_mageTower.TabStop = false;
            this.pb_mageTower.Tag = "mageTowerselecter";
            this.pb_mageTower.Click += new System.EventHandler(this.pb_mageTower_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pictureBox1.Location = new System.Drawing.Point(0, 568);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1011, 84);
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pb_core
            // 
            this.pb_core.BackColor = System.Drawing.Color.Red;
            this.pb_core.Location = new System.Drawing.Point(974, 343);
            this.pb_core.Name = "pb_core";
            this.pb_core.Size = new System.Drawing.Size(26, 44);
            this.pb_core.TabIndex = 38;
            this.pb_core.TabStop = false;
            this.pb_core.Tag = "coreexit";
            // 
            // pb_corner5
            // 
            this.pb_corner5.BackColor = System.Drawing.Color.White;
            this.pb_corner5.Location = new System.Drawing.Point(745, 375);
            this.pb_corner5.Name = "pb_corner5";
            this.pb_corner5.Size = new System.Drawing.Size(31, 5);
            this.pb_corner5.TabIndex = 33;
            this.pb_corner5.TabStop = false;
            this.pb_corner5.Tag = "right";
            // 
            // pb_corner4
            // 
            this.pb_corner4.BackColor = System.Drawing.Color.White;
            this.pb_corner4.Location = new System.Drawing.Point(771, 91);
            this.pb_corner4.Name = "pb_corner4";
            this.pb_corner4.Size = new System.Drawing.Size(5, 27);
            this.pb_corner4.TabIndex = 32;
            this.pb_corner4.TabStop = false;
            this.pb_corner4.Tag = "downdir";
            // 
            // pb_corner3
            // 
            this.pb_corner3.BackColor = System.Drawing.Color.White;
            this.pb_corner3.Location = new System.Drawing.Point(400, 79);
            this.pb_corner3.Name = "pb_corner3";
            this.pb_corner3.Size = new System.Drawing.Size(31, 5);
            this.pb_corner3.TabIndex = 31;
            this.pb_corner3.TabStop = false;
            this.pb_corner3.Tag = "right";
            // 
            // pb_corner2
            // 
            this.pb_corner2.BackColor = System.Drawing.Color.White;
            this.pb_corner2.Location = new System.Drawing.Point(426, 313);
            this.pb_corner2.Name = "pb_corner2";
            this.pb_corner2.Size = new System.Drawing.Size(5, 27);
            this.pb_corner2.TabIndex = 30;
            this.pb_corner2.TabStop = false;
            this.pb_corner2.Tag = "straight";
            // 
            // pb_corner1
            // 
            this.pb_corner1.BackColor = System.Drawing.Color.Transparent;
            this.pb_corner1.Location = new System.Drawing.Point(95, 301);
            this.pb_corner1.Name = "pb_corner1";
            this.pb_corner1.Size = new System.Drawing.Size(28, 5);
            this.pb_corner1.TabIndex = 29;
            this.pb_corner1.TabStop = false;
            this.pb_corner1.Tag = "right";
            // 
            // pb_tower9
            // 
            this.pb_tower9.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower9.Location = new System.Drawing.Point(823, 78);
            this.pb_tower9.Name = "pb_tower9";
            this.pb_tower9.Size = new System.Drawing.Size(57, 53);
            this.pb_tower9.TabIndex = 24;
            this.pb_tower9.TabStop = false;
            this.pb_tower9.Tag = "tower9";
            // 
            // pb_tower10
            // 
            this.pb_tower10.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower10.Location = new System.Drawing.Point(823, 221);
            this.pb_tower10.Name = "pb_tower10";
            this.pb_tower10.Size = new System.Drawing.Size(57, 53);
            this.pb_tower10.TabIndex = 23;
            this.pb_tower10.TabStop = false;
            this.pb_tower10.Tag = "tower10";
            // 
            // pb_tower8
            // 
            this.pb_tower8.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower8.Location = new System.Drawing.Point(613, 301);
            this.pb_tower8.Name = "pb_tower8";
            this.pb_tower8.Size = new System.Drawing.Size(57, 53);
            this.pb_tower8.TabIndex = 22;
            this.pb_tower8.TabStop = false;
            this.pb_tower8.Tag = "tower8";
            // 
            // pb_tower7
            // 
            this.pb_tower7.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower7.Location = new System.Drawing.Point(613, 145);
            this.pb_tower7.Name = "pb_tower7";
            this.pb_tower7.Size = new System.Drawing.Size(57, 53);
            this.pb_tower7.TabIndex = 21;
            this.pb_tower7.TabStop = false;
            this.pb_tower7.Tag = "tower7";
            // 
            // pb_tower2
            // 
            this.pb_tower2.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower2.Location = new System.Drawing.Point(171, 375);
            this.pb_tower2.Name = "pb_tower2";
            this.pb_tower2.Size = new System.Drawing.Size(57, 53);
            this.pb_tower2.TabIndex = 20;
            this.pb_tower2.TabStop = false;
            this.pb_tower2.Tag = "tower2";
            // 
            // pb_tower3
            // 
            this.pb_tower3.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower3.Location = new System.Drawing.Point(355, 375);
            this.pb_tower3.Name = "pb_tower3";
            this.pb_tower3.Size = new System.Drawing.Size(57, 53);
            this.pb_tower3.TabIndex = 19;
            this.pb_tower3.TabStop = false;
            this.pb_tower3.Tag = "tower3";
            // 
            // pb_tower6
            // 
            this.pb_tower6.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower6.Location = new System.Drawing.Point(466, 145);
            this.pb_tower6.Name = "pb_tower6";
            this.pb_tower6.Size = new System.Drawing.Size(57, 53);
            this.pb_tower6.TabIndex = 18;
            this.pb_tower6.TabStop = false;
            this.pb_tower6.Tag = "tower6";
            // 
            // pb_tower5
            // 
            this.pb_tower5.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower5.Location = new System.Drawing.Point(301, 90);
            this.pb_tower5.Name = "pb_tower5";
            this.pb_tower5.Size = new System.Drawing.Size(57, 53);
            this.pb_tower5.TabIndex = 17;
            this.pb_tower5.TabStop = false;
            this.pb_tower5.Tag = "tower5";
            // 
            // pb_tower4
            // 
            this.pb_tower4.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower4.Location = new System.Drawing.Point(289, 210);
            this.pb_tower4.Name = "pb_tower4";
            this.pb_tower4.Size = new System.Drawing.Size(57, 53);
            this.pb_tower4.TabIndex = 16;
            this.pb_tower4.TabStop = false;
            this.pb_tower4.Tag = "tower4";
            // 
            // pb_archNoCoins
            // 
            this.pb_archNoCoins.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_archNoCoins.BackgroundImage = global::Towerdefense.Properties.Resources.notEnoughCoins;
            this.pb_archNoCoins.Location = new System.Drawing.Point(253, 568);
            this.pb_archNoCoins.Name = "pb_archNoCoins";
            this.pb_archNoCoins.Size = new System.Drawing.Size(53, 53);
            this.pb_archNoCoins.TabIndex = 79;
            this.pb_archNoCoins.TabStop = false;
            this.pb_archNoCoins.Tag = "archNoCoins";
            // 
            // pb_bombNoCoins
            // 
            this.pb_bombNoCoins.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_bombNoCoins.BackgroundImage = global::Towerdefense.Properties.Resources.notEnoughCoins;
            this.pb_bombNoCoins.Location = new System.Drawing.Point(470, 568);
            this.pb_bombNoCoins.Name = "pb_bombNoCoins";
            this.pb_bombNoCoins.Size = new System.Drawing.Size(53, 53);
            this.pb_bombNoCoins.TabIndex = 80;
            this.pb_bombNoCoins.TabStop = false;
            this.pb_bombNoCoins.Tag = "bombNoCoins";
            // 
            // pb_ninjaNoCoins
            // 
            this.pb_ninjaNoCoins.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_ninjaNoCoins.BackgroundImage = global::Towerdefense.Properties.Resources.notEnoughCoins;
            this.pb_ninjaNoCoins.Location = new System.Drawing.Point(671, 568);
            this.pb_ninjaNoCoins.Name = "pb_ninjaNoCoins";
            this.pb_ninjaNoCoins.Size = new System.Drawing.Size(53, 53);
            this.pb_ninjaNoCoins.TabIndex = 81;
            this.pb_ninjaNoCoins.TabStop = false;
            this.pb_ninjaNoCoins.Tag = "ninjaNoCoins";
            // 
            // pb_gunNoCoins
            // 
            this.pb_gunNoCoins.BackColor = System.Drawing.Color.DarkSlateGray;
            this.pb_gunNoCoins.BackgroundImage = global::Towerdefense.Properties.Resources.notEnoughCoins;
            this.pb_gunNoCoins.Location = new System.Drawing.Point(883, 568);
            this.pb_gunNoCoins.Name = "pb_gunNoCoins";
            this.pb_gunNoCoins.Size = new System.Drawing.Size(53, 53);
            this.pb_gunNoCoins.TabIndex = 82;
            this.pb_gunNoCoins.TabStop = false;
            this.pb_gunNoCoins.Tag = "gunNoCoins";
            // 
            // pb_rangeTower1
            // 
            this.pb_rangeTower1.BackColor = System.Drawing.Color.Transparent;
            this.pb_rangeTower1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_rangeTower1.Location = new System.Drawing.Point(43, 161);
            this.pb_rangeTower1.Name = "pb_rangeTower1";
            this.pb_rangeTower1.Size = new System.Drawing.Size(199, 193);
            this.pb_rangeTower1.TabIndex = 83;
            this.pb_rangeTower1.TabStop = false;
            this.pb_rangeTower1.Tag = "range";
            this.pb_rangeTower1.Visible = false;
            // 
            // btn_PlaceTower1
            // 
            this.btn_PlaceTower1.BackColor = System.Drawing.Color.Transparent;
            this.btn_PlaceTower1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_PlaceTower1.Location = new System.Drawing.Point(101, 196);
            this.btn_PlaceTower1.Name = "btn_PlaceTower1";
            this.btn_PlaceTower1.Size = new System.Drawing.Size(79, 30);
            this.btn_PlaceTower1.TabIndex = 85;
            this.btn_PlaceTower1.Text = "Place Here";
            this.btn_PlaceTower1.UseVisualStyleBackColor = false;
            this.btn_PlaceTower1.Click += new System.EventHandler(this.btn_PlaceTower1_Click_1);
            // 
            // pb_tower1
            // 
            this.pb_tower1.BackColor = System.Drawing.Color.Transparent;
            this.pb_tower1.Location = new System.Drawing.Point(109, 221);
            this.pb_tower1.Name = "pb_tower1";
            this.pb_tower1.Size = new System.Drawing.Size(57, 53);
            this.pb_tower1.TabIndex = 84;
            this.pb_tower1.TabStop = false;
            this.pb_tower1.Tag = "tower1";
            // 
            // game1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.BackgroundImage = global::Towerdefense.Properties.Resources.lvl1Map;
            this.ClientSize = new System.Drawing.Size(1000, 650);
            this.Controls.Add(this.btn_PlaceTower1);
            this.Controls.Add(this.pb_tower1);
            this.Controls.Add(this.pb_rangeTower1);
            this.Controls.Add(this.pb_gunNoCoins);
            this.Controls.Add(this.pb_ninjaNoCoins);
            this.Controls.Add(this.pb_bombNoCoins);
            this.Controls.Add(this.pb_archNoCoins);
            this.Controls.Add(this.pb_mageNoCoins);
            this.Controls.Add(this.lbl_waveCooldown);
            this.Controls.Add(this.lbl_bluelooncounter);
            this.Controls.Add(this.lbl_redlooncounter);
            this.Controls.Add(this.lbl_wave);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_health);
            this.Controls.Add(this.lbl_coins);
            this.Controls.Add(this.pb_backgroundCoins);
            this.Controls.Add(this.pb_spawn);
            this.Controls.Add(this.btn_PlaceTower5);
            this.Controls.Add(this.pnl_pause);
            this.Controls.Add(this.pnl_start);
            this.Controls.Add(this.lbl_maschineGunPrice);
            this.Controls.Add(this.lbl_ninjaTowerPrice);
            this.Controls.Add(this.lbl_bombTowerPrice);
            this.Controls.Add(this.lbl_archerTowerPrice);
            this.Controls.Add(this.lbl_mageTowerPrice);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_PlaceTower9);
            this.Controls.Add(this.btn_PlaceTower10);
            this.Controls.Add(this.btn_PlaceTower8);
            this.Controls.Add(this.btn_PlaceTower7);
            this.Controls.Add(this.btn_PlaceTower6);
            this.Controls.Add(this.btn_PlaceTower4);
            this.Controls.Add(this.btn_PlaceTower3);
            this.Controls.Add(this.btn_PlaceTower2);
            this.Controls.Add(this.pb_ninjaTower);
            this.Controls.Add(this.pb_maschingunTower);
            this.Controls.Add(this.pb_BombTower);
            this.Controls.Add(this.pb_archerTower);
            this.Controls.Add(this.pb_mageTower);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_smallestenemy);
            this.Controls.Add(this.lbl_test);
            this.Controls.Add(this.pb_core);
            this.Controls.Add(this.pb_corner5);
            this.Controls.Add(this.pb_corner4);
            this.Controls.Add(this.pb_corner3);
            this.Controls.Add(this.pb_corner2);
            this.Controls.Add(this.pb_corner1);
            this.Controls.Add(this.pb_tower9);
            this.Controls.Add(this.pb_tower10);
            this.Controls.Add(this.pb_tower8);
            this.Controls.Add(this.pb_tower7);
            this.Controls.Add(this.pb_tower2);
            this.Controls.Add(this.pb_tower3);
            this.Controls.Add(this.pb_tower6);
            this.Controls.Add(this.pb_tower5);
            this.Controls.Add(this.pb_tower4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "game1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "";
            this.Text = "game";
            this.Load += new System.EventHandler(this.game_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.game1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pb_mageNoCoins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_backgroundCoins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_spawn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ninjaTower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_maschingunTower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_BombTower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_archerTower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mageTower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_core)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_corner1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_archNoCoins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_bombNoCoins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ninjaNoCoins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_gunNoCoins)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_rangeTower1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tower1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pb_tower4;
        private System.Windows.Forms.PictureBox pb_tower5;
        private System.Windows.Forms.PictureBox pb_tower6;
        private System.Windows.Forms.PictureBox pb_tower3;
        private System.Windows.Forms.PictureBox pb_tower2;
        private System.Windows.Forms.PictureBox pb_tower7;
        private System.Windows.Forms.PictureBox pb_tower8;
        private System.Windows.Forms.PictureBox pb_tower10;
        private System.Windows.Forms.PictureBox pb_tower9;
        private System.Windows.Forms.Timer playtimer;
        private System.Windows.Forms.PictureBox pb_corner1;
        private System.Windows.Forms.PictureBox pb_corner2;
        private System.Windows.Forms.PictureBox pb_corner3;
        private System.Windows.Forms.PictureBox pb_corner4;
        private System.Windows.Forms.PictureBox pb_corner5;
        private System.Windows.Forms.PictureBox pb_core;
        private System.Windows.Forms.Timer enemyspawning;
        private System.Windows.Forms.Label lbl_test;
        private System.Windows.Forms.Timer bullet_speed;
        private System.Windows.Forms.Label lbl_smallestenemy;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pb_mageTower;
        private System.Windows.Forms.PictureBox pb_archerTower;
        private System.Windows.Forms.PictureBox pb_BombTower;
        private System.Windows.Forms.PictureBox pb_maschingunTower;
        private System.Windows.Forms.PictureBox pb_ninjaTower;
        private System.Windows.Forms.Button btn_PlaceTower2;
        private System.Windows.Forms.Button btn_PlaceTower3;
        private System.Windows.Forms.Button btn_PlaceTower4;
        private System.Windows.Forms.Button btn_PlaceTower6;
        private System.Windows.Forms.Button btn_PlaceTower7;
        private System.Windows.Forms.Button btn_PlaceTower8;
        private System.Windows.Forms.Button btn_PlaceTower10;
        private System.Windows.Forms.Button btn_PlaceTower9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_mageTowerPrice;
        private System.Windows.Forms.Label lbl_archerTowerPrice;
        private System.Windows.Forms.Label lbl_bombTowerPrice;
        private System.Windows.Forms.Label lbl_ninjaTowerPrice;
        private System.Windows.Forms.Label lbl_maschineGunPrice;
        private System.Windows.Forms.Panel pnl_start;
        private System.Windows.Forms.Panel pnl_pause;
        private System.Windows.Forms.Button btn_PlaceTower5;
        private System.Windows.Forms.PictureBox pb_spawn;
        private System.Windows.Forms.PictureBox pb_backgroundCoins;
        private System.Windows.Forms.Label lbl_health;
        private System.Windows.Forms.Label lbl_coins;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_wave;
        private System.Windows.Forms.Label lbl_redlooncounter;
        private System.Windows.Forms.Label lbl_bluelooncounter;
        private System.Windows.Forms.Label lbl_waveCooldown;
        private System.Windows.Forms.Timer bullet_spawning;
        private System.Windows.Forms.PictureBox pb_mageNoCoins;
        private System.Windows.Forms.PictureBox pb_archNoCoins;
        private System.Windows.Forms.PictureBox pb_bombNoCoins;
        private System.Windows.Forms.PictureBox pb_ninjaNoCoins;
        private System.Windows.Forms.PictureBox pb_gunNoCoins;
        private System.Windows.Forms.PictureBox pb_rangeTower1;
        private System.Windows.Forms.Button btn_PlaceTower1;
        private System.Windows.Forms.PictureBox pb_tower1;
    }
}